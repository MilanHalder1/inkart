'use strict';

const Product = require('../models/Product');
const { deleteImage } = require('../config/cloudinary');
const AppError = require('../utilities/AppError');
const catchAsync = require('../utilities/CatchAsync');
const APIFeatures = require('../utilities/apiFeatures');

const getAllProducts = catchAsync(async (req, res) => {
  const features = new APIFeatures(
    Product.find().populate('category', 'name slug'),
    req.query
  ).filter().sort().limitFields().paginate();

  const [products, total] = await Promise.all([
    features.query,
    Product.countDocuments(),
  ]);

  res.status(200).json({
    success: true,
    results: products.length,
    total,
    data: { products },
  });
});

const createProduct = catchAsync(async (req, res, next) => {

  const images =
    req.files?.productImages?.map((file) => ({
      url: file.path,
      publicId: file.filename,
    })) || [];
  // Parse quantity pricing if sent via form-data
  if (req.body.quantityPricing) {
    req.body.quantityPricing =
      JSON.parse(req.body.quantityPricing);
  }

  if (req.body.availableColors) {
    req.body.availableColors =
      typeof req.body.availableColors === 'string'
        ? JSON.parse(req.body.availableColors)
        : req.body.availableColors;
  }
  let variants = [];

  if (req.body.variants) {
    variants =
      typeof req.body.variants === 'string'
        ? JSON.parse(req.body.variants)
        : req.body.variants;
  }
  variants.forEach((variant, index) => {

    const frontImages =
      req.files?.[`colorFront_${index}`] || [];

    const backImages =
      req.files?.[`colorBack_${index}`] || [];

    variant.images = [

      ...frontImages.map(file => ({
        type: 'front',
        url: file.path,
        publicId: file.filename,
      })),

      ...backImages.map(file => ({
        type: 'back',
        url: file.path,
        publicId: file.filename,
      })),

    ];
  });
  const product = await Product.create({
    ...req.body,
    images,
    variants,

    createdBy: req.user.id,
  });

  res.status(201).json({
    success: true,
    data: { product },
  });
});

const getProduct = catchAsync(async (req, res, next) => {
  const product = await Product.findById(req.params.id).populate('category', 'name slug');
  if (!product) return next(new AppError('Product not found.', 404));
  res.status(200).json({ success: true, data: { product } });
});

const updateProduct = catchAsync(async (req, res, next) => {
  const product = await Product.findById(req.params.id);

  if (!product) {
    return next(new AppError('Product not found.', 404));
  }

  let variants = [];

  // ==========================================
  // Parse JSON fields
  // ==========================================

  try {
    if (req.body.quantityPricing) {
      req.body.quantityPricing = JSON.parse(req.body.quantityPricing);
    }

    if (req.body.variants) {
      variants =
        typeof req.body.variants === 'string'
          ? JSON.parse(req.body.variants)
          : req.body.variants;
    }

    if (req.body.availableColors) {
      req.body.availableColors =
        typeof req.body.availableColors === 'string'
          ? JSON.parse(req.body.availableColors)
          : req.body.availableColors;
    }

    if (req.body.specifications) {
      req.body.specifications = JSON.parse(req.body.specifications);
    }

  } catch (err) {
    return next(new AppError('Invalid JSON in request body.', 400));
  }

  // ==========================================
  // Attach Color Images
  // ==========================================

  variants.forEach((variant, index) => {

    const oldVariant = product.variants.find(
      v => v.colorName === variant.colorName
    );

    const frontImages =
      req.files?.[`colorFront_${index}`] || [];

    const backImages =
      req.files?.[`colorBack_${index}`] || [];

    if (frontImages.length || backImages.length) {

      variant.images = [

        ...frontImages.map(file => ({
          type: 'front',
          url: file.path,
          publicId: file.filename,
        })),

        ...backImages.map(file => ({
          type: 'back',
          url: file.path,
          publicId: file.filename,
        })),

      ];

    }
    else {

      variant.images = oldVariant?.images || [];

    }

  });

  // ==========================================
  // Main Product Images
  // ==========================================

  if (req.files?.productImages?.length) {

    const newImages = req.files.productImages.map(file => ({
      url: file.path,
      publicId: file.filename,
    }));

    req.body.images = [
      ...(product.images || []),
      ...newImages,
    ];
  }

  req.body.variants = variants;

  // ==========================================
  // Update
  // ==========================================

  const updated = await Product.findByIdAndUpdate(
    req.params.id,
    req.body,
    {
      new: true,
      runValidators: true,
    }
  );

  res.status(200).json({
    success: true,
    data: {
      product: updated,
    },
  });
});

const deleteProduct = catchAsync(async (req, res, next) => {
  const product = await Product.findByIdAndDelete(req.params.id);

  if (!product) {
    return next(new AppError('Product not found.', 404));
  }

  res.status(200).json({
    success: true,
    message: 'Product deleted successfully.'
  });
});

const deleteProductImage = catchAsync(async (req, res, next) => {
  const product = await Product.findById(req.params.id);
  if (!product) return next(new AppError('Product not found.', 404));

  const imageIndex = product.images.findIndex((img) => img.publicId === req.params.publicId);
  if (imageIndex === -1) return next(new AppError('Image not found.', 404));

  await deleteImage(req.params.publicId);
  product.images.splice(imageIndex, 1);
  await product.save();

  res.status(200).json({ success: true, data: { images: product.images } });
});

// Stock management for stocked products
const updateStock = catchAsync(async (req, res, next) => {
  const { quantity, variantId, operation = 'set' } = req.body;
  const product = await Product.findById(req.params.id);
  if (!product) return next(new AppError('Product not found.', 404));
  if (product.productType !== 'stocked') return next(new AppError('Stock management only applies to stocked products.', 400));

  if (variantId) {
    const variant = product.variants.id(variantId);
    if (!variant) return next(new AppError('Variant not found.', 404));
    if (operation === 'add') variant.stock += quantity;
    else if (operation === 'subtract') variant.stock = Math.max(0, variant.stock - quantity);
    else variant.stock = quantity;
  } else {
    if (operation === 'add') product.stock += quantity;
    else if (operation === 'subtract') product.stock = Math.max(0, product.stock - quantity);
    else product.stock = quantity;
  }

  await product.save();
  res.status(200).json({
    success: true,
    message: 'Stock updated.',
    data: { stock: variantId ? product.variants.id(variantId).stock : product.stock },
  });
});

module.exports = { getAllProducts, createProduct, getProduct, updateProduct, deleteProduct, deleteProductImage, updateStock };